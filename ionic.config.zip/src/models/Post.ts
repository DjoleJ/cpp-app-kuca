export interface Post {
    Date?: any,
    Time?: any,
    Price?: any
}

// export interface PageInterface {
//     title: string,
//     pageName: string,
//     tabComponent?: any,
//     index?: number,
//     icon: string,
//     openTab?: any
// }