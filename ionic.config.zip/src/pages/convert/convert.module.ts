import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConvertPage } from './convert';

@NgModule({
  declarations: [
    ConvertPage,
  ],
  imports: [
    IonicPageModule.forChild(ConvertPage),
  ],
})
export class ConvertPageModule {}
