import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { DataProvider } from '../../providers/data/data';
import { Post } from '../../models/Post';

@IonicPage()
@Component({
  selector: 'page-index',
  templateUrl: 'index.html',
})
export class IndexPage {

  posts: Post;

  // hide: boolean = false;

  constructor(public navCtrl: NavController, public navParams: NavParams, private DataService: DataProvider) {
  }



  ionViewDidLoad() {
    this.DataService.getRemoteData().subscribe(posts => {
       
      // this.posts["hide"] = true;
      
      this.posts = posts;

      


      console.log(this.posts.Price);
      
    });

  }

    // onShowGraph(post: Post) {
    //   post.hide = !post.hide;
    // }



}
